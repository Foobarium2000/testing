function onEvent(name)
	if name == 'trapBGOFF' then
		removeLuaSprite('lightning1', true);
		removeLuaSprite('lightning2', true);
	end
end


