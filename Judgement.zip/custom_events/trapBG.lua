function onEvent(name)
	if name == 'trapBG' then
		makeLuaSprite('lightning1', '21/Blue', 0, -500);
		addLuaSprite('lightning1', true);
		makeLuaSprite('lightning2', '21/Pink', 0, -600);
		addLuaSprite('lightning2', true);
	end
end

function onUpdate(elapsed)
	--make notes up and down
    if curStep >= 0 then
  
		songPos = getSongPosition()
	
		local currentBeat = (songPos/800)*(bpm/80)
	
		doTweenY('bgTweenY', 'lightning1', -310-220*math.sin((currentBeat*0.20)*math.pi),0.01)
		doTweenY('bg2TweenY', 'lightning2', -260-220*math.sin((currentBeat*0.10)*math.pi),0.01)
	
	end
end


