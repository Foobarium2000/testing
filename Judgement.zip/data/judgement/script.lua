
local xx = 650;
local yy = 600;
local xx2 = 830;
local yy2 = 660;
local ofs = 50;
local followchars = true;
local del = 0;
local del2 = 0;

function onCreate()
	setPropertyFromClass('GameOverSubstate', 'characterName', '9+10 is 21'); --Character json file for the death animation
	setPropertyFromClass('GameOverSubstate', 'loopSoundName', 'gameOver21'); --put in mods/music/
	setPropertyFromClass('GameOverSubstate', 'endSoundName', 'gameOverend21'); --put in mods/music/
    return Function_Continue;
end
function onCreatePost()
	time = 0.02;
	for i = 0, getProperty('playerStrums.length')-1 do
		setPropertyFromGroup('playerStrums', i, 'x', 50 * i + 340);
	end
	for i = 0, getProperty('opponentStrums.length')-1 do
		setPropertyFromGroup('opponentStrums', i, 'x', 50 * i + -680);
	end	
	return Function_Continue;
end

function onUpdate(elapsed)
	time = 0.01;
	for i = 0, getProperty('opponentStrums.length')-1 do
		noteTweenAlpha("Alpha"..i, i, 0, time, "linear")
	end
	holdCap = stepCrochet * 0.004;
	if holdTimers.normalbf >= 0 then
		holdTimers.normalbf = holdTimers.normalbf + elapsed;
		if holdTimers.normalbf >= holdCap then
			playAnimation('normalbf', 12, false);
			holdTimers.normalbf = -1;
		end
	end	
	if del > 0 then
		del = del - 1
	end
	if del2 > 0 then
		del2 = del2 - 1
	end
    if followchars == true then
        if mustHitSection == false then
        else

            if getProperty('boyfriend.animation.curAnim.name') == 'singLEFT' then
                triggerEvent('Camera Follow Pos',xx2-ofs,yy2)
            end
            if getProperty('boyfriend.animation.curAnim.name') == 'singRIGHT' then
                triggerEvent('Camera Follow Pos',xx2+ofs,yy2)
            end
            if getProperty('boyfriend.animation.curAnim.name') == 'singUP' then
                triggerEvent('Camera Follow Pos',xx2,yy2-ofs)
            end
            if getProperty('boyfriend.animation.curAnim.name') == 'singDOWN' then
                triggerEvent('Camera Follow Pos',xx2,yy2+ofs)
            end
	    if getProperty('boyfriend.animation.curAnim.name') == 'idle' then
                triggerEvent('Camera Follow Pos',xx2,yy2)
             end
        end
    else
        triggerEvent('Camera Follow Pos','','')
    end	
end


function opponentNoteHit()
    health = getProperty('health')
    if getProperty('health') > 0 then
        setProperty('health', health- 0.01);
    end
end












-- sussy baka
function onCreate()
	if (songName == 'Judgement') then
		makeAnimationList();
		makeOffsets();
	
		makeAnimatedLuaSprite('normalbf', 'characters/bfhand', defaultBoyfriendX+270, defaultBoyfriendY + 700);
		addAnimationByPrefix('normalbf', 'idle', 'bf idle', 24, false);
		addAnimationByPrefix('normalbf', 'singLEFT', 'bf left0', 24, false);
		addAnimationByPrefix('normalbf', 'singDOWN', 'bf down0', 24, false);
		addAnimationByPrefix('normalbf', 'singUP', 'bf up0', 24, false);
		addAnimationByPrefix('normalbf', 'singRIGHT', 'bf right0', 24, false);
		addAnimationByPrefix('normalbf', 'singLEFTmiss', 'bf left miss', 24, false);
		addAnimationByPrefix('normalbf', 'singDOWNmiss', 'bf down miss', 24, false);
		addAnimationByPrefix('normalbf', 'singUPmiss', 'bf up miss', 24, false);
		addAnimationByPrefix('normalbf', 'singRIGHTmiss', 'bf right miss', 24, false);


		addLuaSprite('normalbf', true);

		playAnimation('normalbf', 12, true);
	end
end

animationsList = {}
holdTimers = {normalbf = -1.0};
noteDatas = {normalbf = 0};
function makeAnimationList()
	animationsList[0] = 'singLEFT';
	animationsList[1] = 'singLEFT';
    animationsList[2] = 'singDOWN';
	animationsList[3] = 'singUP';
	animationsList[4] = 'singRIGHT';
	animationsList[5] = 'singUP';
	animationsList[6] = 'singUP';
	animationsList[7] = 'singLEFT';
    animationsList[8] = 'singDOWN';
    animationsList[9] = 'singUP';
	animationsList[10] = 'singRIGHT';
	animationsList[11] = 'singRIGHT';
	animationsList[12] = 'idle';
	animationsList[13] = 'singLEFTmiss';
	animationsList[14] = 'singLEFTmiss';
	animationsList[15] = 'singDOWNmiss';
	animationsList[16] = 'singUPmiss';
	animationsList[17] = 'singRIGHTmiss';
	animationsList[18] = 'singUPmiss';
	animationsList[19] = 'singUPmiss';				
	animationsList[20] = 'singLEFTmiss';
	animationsList[21] = 'singDOWNmiss';
	animationsList[22] = 'singUPmiss';
	animationsList[23] = 'singRIGHTmiss';
	animationsList[24] = 'singRIGHTmiss';			
end

offsetsnormalbf = {};
function makeOffsets()
	offsetsnormalbf[0] = {x = 5, y = -5}; --left
	offsetsnormalbf[1] = {x = 5, y = -5}; --left
    offsetsnormalbf[2] = {x = -10, y = -50}; --down
	offsetsnormalbf[3] = {x = -29, y = 27}; --up
	offsetsnormalbf[4] = {x = -48, y = -7}; --right
	offsetsnormalbf[5] = {x = -29, y = 27}; --up
	offsetsnormalbf[6] = {x = -29, y = 27}; --up
	offsetsnormalbf[7] = {x = 5, y = -5}; --left
    offsetsnormalbf[8] = {x = -10, y = -50}; --down
	offsetsnormalbf[9] = {x = -29, y = 27}; --up
	offsetsnormalbf[10] = {x = -48, y = -7}; --right
	offsetsnormalbf[11] = {x = -48, y = -7}; --right				
	offsetsnormalbf[12] = {x = -5, y = 0}; --idle
	offsetsnormalbf[13] = {x = 7, y = 19}; --leftmiss
	offsetsnormalbf[14] = {x = 7, y = 19}; --leftmiss
	offsetsnormalbf[15] = {x = -15, y = -19}; --downmiss
	offsetsnormalbf[16] = {x = -36, y = 27}; --upmiss		
	offsetsnormalbf[17] = {x = -44, y = 22}; --rightmiss
	offsetsnormalbf[18] = {x = -36, y = 27}; --upmiss	
	offsetsnormalbf[19] = {x = -36, y = 27}; --upmiss
	offsetsnormalbf[20] = {x = 7, y = 19}; --leftmiss
	offsetsnormalbf[21] = {x = -15, y = -19}; --downmiss
	offsetsnormalbf[22] = {x = -36, y = 27}; --upmiss		
	offsetsnormalbf[23] = {x = -44, y = 22}; --rightmiss			
	offsetsnormalbf[24] = {x = -44, y = 22}; --rightmiss											
end

function goodNoteHit(id, direction, noteType, isSustainNote)
	if not isSustainNote then
		noteDatas.normalbf = direction;
	end	
	characterToPlay = 'normalbf'
	animToPlay = noteDatas.normalbf;
	holdTimers.normalbf = 0;
	
	playAnimation(characterToPlay, animToPlay, true);
end

function noteMiss(id, direction, noteType)
	noteDatas.normalbf = direction + 13;
	characterToPlay = 'normalbf'
	animToPlay = noteDatas.normalbf;
	
	playAnimation(characterToPlay, animToPlay, true);
end


function onCountdownTick(counter)
	beatHitDance(counter);
end

function onBeatHit()
	beatHitDance(curBeat);
end

function beatHitDance(counter)
	if counter % 2 == 0 then
		if holdTimers.normalbf < 0 then
			playAnimation('normalbf', 12, false);
		end
	end
end

function playAnimation(character, animId, forced)
	-- 0 = idle
	-- 1 = singLEFT
	-- 2 = singDOWN
	-- 3 = singUP
	-- 4 = singRIGHT
	animName = animationsList[animId];
	--debugPrint(animName);
	if character == 'normalbf' then
		objectPlayAnimation('normalbf', animName, forced); -- this part is easily broke if you use objectPlayAnim (I have no idea why its like this)
		setProperty('normalbf.offset.x', offsetsnormalbf[animId].x);
		setProperty('normalbf.offset.y', offsetsnormalbf[animId].y);
	end
end



local keepScroll = false




